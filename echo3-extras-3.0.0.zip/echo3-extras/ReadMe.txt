----------------------------------------------------------------------
Echo Extras, version 3.0
Copyright (C) 2005-2009 NextApp, Inc.

http://echo.nextapp.com/site/echo3/addons/extras

----------------------------------------------------------------------
Echo Extras is licensed under the Mozilla Public License.
Please see the "Licensing.txt" file in the /Licensing folder for more
information.

----------------------------------------------------------------------
This archive/package contains the following directory structure:

/SourceCode         - Provides the source code of the framework.  

/BinaryLibraries    - Provides binary versions of the Echo Extras libraries.

/BinaryApplications - Contains binary test and example applications,
                      packages as Web Archives (WAR files).

/Licensing          - Contains licensing information.
                      
------------------------------------------------------------------------------
The following developer resources are available for the Echo platform:

http://echo.nextapp.com       - Echo Home Page
http://forum.nextapp.com      - Developer Forums: Use this site to ask
                                questions about the framework and receive
                                (or provide) community support.
http://bugs.nextapp.com       - Issue Tracking System: Please report any bugs
                                in the framework and make any feature requests
                                using this site.

------------------------------------------------------------------------------
NextApp, Inc.                  
2549-B Eastbluff Drive #201
Newport Beach, CA 92660
USA        

TEL: +1.949.340.2097

http://www.nextapp.com
